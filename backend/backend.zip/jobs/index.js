import './defunctionsCovid.js';
import './fecundityByCCAA.js';
import './infantMortalityRate.js';
import './infantDefunctionsPerYear.js';
